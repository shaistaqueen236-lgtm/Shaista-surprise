# Flash AI — Hey Flash Android MVP v2

## Features
- "Hey Flash" / "Flash" voice trigger phrase
- Foreground microphone service
- Hindi speech recognition
- Voice replies with Android TextToSpeech
- Natural-ish app launch commands
- Finds installed apps exposed through Android launcher intents
- Examples:
  - Hey Flash, YouTube kholo
  - Flash, Instagram open karo
  - Hey Flash, WhatsApp kholo
  - Flash, Chrome chalao

## Important Android behavior
This MVP keeps a visible foreground-service notification while the microphone service is active. Android may stop or restrict microphone/background work depending on device settings and battery optimization.

The wake phrase here is implemented by speech recognition: Flash listens for short speech segments and checks whether the result contains "Hey Flash" or starts with "Flash". This is NOT a dedicated always-on DSP wake-word engine.

## Build
Open in Android Studio, sync Gradle, connect an Android phone, and Run.

For production, replace the speech-based wake detector with a dedicated on-device wake-word engine and add explicit privacy controls.
