package com.flash.ai

import android.content.Context
import android.content.Intent
import java.util.Locale

object CommandEngine {
    data class AppInfo(val label: String, val packageName: String)

    fun apps(context: Context): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    fun run(context: Context, raw: String): String {
        val c = raw.lowercase(Locale.getDefault())
            .replace(Regex("[,.!?]"), " ")
            .replace(Regex("\s+"), " ")
            .trim()
            .removePrefix("hey flash")
            .removePrefix("flash")
            .trim()

        if (c.isBlank()) return "Haan, bolo."

        val prefixes = listOf(
            "open ", "launch ", "start ", "khol ", "kholo ",
            "khol do ", "open karo ", "kholo na ", "chalao ", "chala "
        )
        var target = c
        for (p in prefixes) if (target.startsWith(p)) {
            target = target.removePrefix(p).trim()
            break
        }

        // Common nicknames/aliases.
        target = when {
            target == "yt" || target.contains("youtube") -> "youtube"
            target == "ig" || target.contains("instagram") || target == "insta" -> "instagram"
            target == "wa" || target.contains("whatsapp") -> "whatsapp"
            target.contains("chrome") -> "chrome"
            target.contains("camera") || target.contains("cam") -> "camera"
            else -> target
        }

        val match = apps(context).firstOrNull {
            val n = normalize(it.label)
            n == normalize(target) ||
            (target.length >= 3 && n.contains(normalize(target)))
        }

        if (match != null) {
            val launch = context.packageManager.getLaunchIntentForPackage(match.packageName)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                return "${match.label} open kar diya."
            }
        }
        return ""$target" naam ka installed app nahi mila."
    }

    private fun normalize(s: String) =
        s.lowercase(Locale.getDefault()).replace(Regex("[^a-z0-9]"), "")
}
