package com.flash.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var tts: TextToSpeech

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            startFlashService()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { tts.language = Locale("hi", "IN") }

        setContent {
            var status by remember { mutableStateOf("Flash ready ⚡") }

            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.padding(24.dp)) {
                        Spacer(Modifier.height(30.dp))
                        Text("⚡ FLASH AI", style = MaterialTheme.typography.headlineLarge)
                        Spacer(Modifier.height(12.dp))
                        Text(status)
                        Spacer(Modifier.height(24.dp))
                        Button(onClick = {
                            permissionLauncher.launch(arrayOf(
                                Manifest.permission.RECORD_AUDIO,
                                Manifest.permission.POST_NOTIFICATIONS
                            ))
                            status = "Hey Flash mode start ho raha hai..."
                        }) { Text("Start Hey Flash") }

                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(onClick = {
                            stopService(Intent(this@MainActivity, FlashVoiceService::class.java))
                            status = "Flash voice mode stopped."
                        }) { Text("Stop") }

                        Spacer(Modifier.height(24.dp))
                        Text("Try: "Hey Flash, YouTube kholo"")
                        Text("Try: "Flash, Instagram open karo"")
                        Text("Try: "Hey Flash, WhatsApp kholo"")
                    }
                }
            }
        }
    }

    private fun startFlashService() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val i = Intent(this, FlashVoiceService::class.java)
        startForegroundService(i)
    }

    override fun onDestroy() {
        tts.shutdown()
        super.onDestroy()
    }
}
