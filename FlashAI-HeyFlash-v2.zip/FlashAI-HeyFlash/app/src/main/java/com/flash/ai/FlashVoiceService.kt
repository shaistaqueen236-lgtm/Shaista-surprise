package com.flash.ai

import android.app.*
import android.content.*
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import java.util.Locale

class FlashVoiceService : Service() {
    private lateinit var recognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private var listening = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = Notification.Builder(this, "flash_voice")
            .setContentTitle("Flash AI")
            .setContentText("Listening for "Hey Flash"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        startForeground(77, notification)

        tts = TextToSpeech(this) { tts.language = Locale("hi", "IN") }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                listening = false
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                handle(text)
                Handler(Looper.getMainLooper()).postDelayed({ listen() }, 500)
            }
            override fun onError(error: Int) {
                listening = false
                Handler(Looper.getMainLooper()).postDelayed({ listen() }, 700)
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        listen()
    }

    private fun listen() {
        if (listening) return
        listening = true
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer.startListening(i)
    }

    private fun handle(spoken: String) {
        val lower = spoken.lowercase(Locale.getDefault()).trim()
        val hasWake = lower.contains("hey flash") || lower.startsWith("flash")
        if (!hasWake) return

        val reply = CommandEngine.run(this, spoken)
        tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "flash_reply")
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("flash_voice", "Flash voice assistant", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onDestroy() {
        recognizer.destroy()
        tts.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
