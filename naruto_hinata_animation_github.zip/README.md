# Naruto × Hinata — Evening

A small, original HTML/CSS/JS fan-animation scene inspired by Naruto and Hinata.

## Run
Open `index.html` in a browser.

## GitHub Pages
1. Upload `index.html` to a GitHub repository.
2. Open **Settings → Pages**.
3. Deploy from the `main` branch/root folder.
4. Open the generated Pages URL.

This project uses CSS-drawn, simplified characters and does not include official Naruto artwork or audio.
